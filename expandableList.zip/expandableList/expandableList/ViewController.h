//
//  ViewController.h
//  expandableList
//
//  Created by Adamas Inc on 9/13/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>


@end

