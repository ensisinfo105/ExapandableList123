//
//  ViewController.m
//  expandableList
//
//  Created by Adamas Inc on 9/13/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableArray *arrayForBool,*totalListOfArray,*respArray;
    NSArray *sectionTitleArray;
    UITableView *tableList;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tableList = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    tableList.translatesAutoresizingMaskIntoConstraints = NO;
    tableList.dataSource=self;
    tableList.delegate=self;
    tableList.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    tableList.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    tableList.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [tableList registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    tableList.estimatedRowHeight = 44.0;
    tableList.rowHeight = UITableViewAutomaticDimension;
    [self.view addSubview:tableList];
    
    NSDictionary * views = NSDictionaryOfVariableBindings(tableList);
    
    NSArray * horizentalConstraint = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[tableList]-0-|" options:0 metrics:nil views:views];
    
    NSArray * verticalConstraint = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-20-[tableList]-0-|"options:0 metrics:nil views:views];
    
    [self.view addConstraints:horizentalConstraint];
    [self.view addConstraints:verticalConstraint];
    
    [self initialization];
    
}

-(void)initialization
{
    arrayForBool=[[NSMutableArray alloc]init];
    
    sectionTitleArray=[[NSArray alloc]initWithObjects:
                       @"Apple",
                       @"Strawberry",
                       @"Grapes",
                       @"Orange",
                       @"Banana",
                       nil];
   
    
    NSArray *new0=[[NSArray alloc]initWithObjects:@"Apple", @"Strawberry",@"Grapes",@"Orange", nil];
    
    NSArray *new1=[[NSArray alloc]initWithObjects:@"Apple1", @"Strawberry1",@"Grapes1",@"Orange1"@"Orange1", nil];
    
    NSArray *new2=[[NSArray alloc]initWithObjects:@"Apple2", @"Strawberry2",@"Grapes2",@"Orange2", nil];
    
    NSArray *new3=[[NSArray alloc]initWithObjects:@"Apple3", @"Strawberry3",@"Grapes3",@"Orange3",@"Orange3", nil];
    
    NSArray *new4=[[NSArray alloc]initWithObjects:@"Apple4", @"Strawberry4",@"Grapes4",@"Grapes4", nil];
    
    totalListOfArray=[[NSMutableArray alloc]init];
    
    
    [totalListOfArray addObject:new0];
    [totalListOfArray addObject:new1];
    [totalListOfArray addObject:new2];
    [totalListOfArray addObject:new3];
    [totalListOfArray addObject:new4];
    
    for (int i=0; i< [sectionTitleArray count]; i++) {
        
        [arrayForBool addObject:[NSNumber numberWithBool:NO]];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if ([[arrayForBool objectAtIndex:section] boolValue]) {
        
        NSLog(@"respArray count is ======> %d",respArray.count);
        return [respArray count];
        //return 1;
    }
    
    else
        
        return 0;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"cell2";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    BOOL manyCells  = [[arrayForBool objectAtIndex:indexPath.section] boolValue];
    
    //    /********** If the section supposed to be closed *******************/
    if(!manyCells)
    {
        cell.backgroundColor=[UIColor clearColor];
        
        cell.textLabel.text=@"";
    }
    /********** If the section supposed to be Opened *******************/
    else
    {
        cell.textLabel.text=[NSString stringWithFormat:@"%@",[respArray objectAtIndex:indexPath.row]];
        cell.textLabel.font=[UIFont systemFontOfSize:15.0f];
        cell.backgroundColor=[UIColor whiteColor];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
    }
    
    cell.textLabel.textColor=[UIColor blackColor];
    
    /********** Add a custom Separator with cell *******************/
    UIView* separatorLineView = [[UIView alloc] initWithFrame:CGRectMake(0, 40, tableList.frame.size.width, 1)];
    separatorLineView.backgroundColor = [UIColor blackColor];
    [cell.contentView addSubview:separatorLineView];
    
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [sectionTitleArray count];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    /*************** Close the section, once the data is selected ***********************************/
    [arrayForBool replaceObjectAtIndex:indexPath.section withObject:[NSNumber numberWithBool:NO]];
    
    [tableList reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationAutomatic];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[arrayForBool objectAtIndex:indexPath.section] boolValue]) {
        return 40;
    }
    return 0;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 11;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *sectionView1=[[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width,1)];
    sectionView1.backgroundColor = [UIColor whiteColor];
    
    return  sectionView1;
}

#pragma mark - Creating View for TableView Section

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView *headerview = [[UIView alloc] init];
    headerview.backgroundColor = [UIColor lightGrayColor];
    headerview.frame = CGRectMake(0, 0, tableView.frame.size.width, 80);
    headerview.tag=section;
    
    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, tableList.frame.size.width, 25)];
    label1.text = @"Hi";
    [headerview addSubview:label1];
    
    UITapGestureRecognizer  *headerTapped   = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(sectionHeaderTapped:)];
    [headerview addGestureRecognizer:headerTapped];
    
    return headerview;
    
}

#pragma mark - Table header gesture tapped

- (void)sectionHeaderTapped:(UITapGestureRecognizer *)gestureRecognizer{
    
    
      NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:gestureRecognizer.view.tag];
    
        NSLog(@" index ---->>> %ld",(long)indexPath.section);
    
        for (int i=0; i<[sectionTitleArray count]; i++){
    
            if (indexPath.section == i) {
    
                BOOL collapsed  = [[arrayForBool objectAtIndex:indexPath.section] boolValue];
                for (int i=0; i<[sectionTitleArray count]; i++) {
                    if (indexPath.section==i) {
                        [arrayForBool replaceObjectAtIndex:i withObject:[NSNumber numberWithBool:!collapsed]];
                    }else{
                        [arrayForBool replaceObjectAtIndex:i withObject:[NSNumber numberWithBool:collapsed]];
                    }
                }
                [self selectedOption:(int)indexPath.section];
    
                [tableList reloadSections:[NSIndexSet indexSetWithIndex:gestureRecognizer.view.tag] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
}

-(NSMutableArray *)selectedOption:(int)mySelectedItemData{
    
    NSLog(@"%d",mySelectedItemData);
    NSMutableArray *arrayValue=[[NSMutableArray alloc]init];
    respArray=[[NSMutableArray alloc]init];
    
    NSLog(@"%@",[totalListOfArray objectAtIndex:mySelectedItemData]);
    NSLog(@"%d",[[totalListOfArray objectAtIndex:mySelectedItemData] count]);
    
    for (int i=0; i< [[totalListOfArray objectAtIndex:mySelectedItemData]count]; i++) {
        
        [arrayValue addObject:[[totalListOfArray objectAtIndex:mySelectedItemData] objectAtIndex:i]];
        NSLog(@"array value is =======> %@",arrayValue);
        [arrayForBool addObject:[NSNumber numberWithBool:NO]];
    }
    
    [tableList reloadSections:[NSIndexSet indexSetWithIndex:mySelectedItemData] withRowAnimation:UITableViewRowAnimationAutomatic];
    
    respArray=[arrayValue mutableCopy];
    NSLog(@"respArray items are =====> %@",respArray);
    
    return arrayValue;
}

@end
